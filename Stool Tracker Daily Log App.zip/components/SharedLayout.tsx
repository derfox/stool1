import React from 'react';
import { useAuth } from '../helpers/useAuth';
import { Button } from './Button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from './DropdownMenu';
import { User, LogOut } from 'lucide-react';
import styles from './SharedLayout.module.css';

export const SharedLayout = ({ children }: { children: React.ReactNode }) => {
  const { authState, logout } = useAuth();

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.log('Logout error:', error);
    }
  };

  return (
    <div className={styles.appContainer}>
      <header className={styles.header}>
        <div className={styles.headerContent}>
          <h1 className={styles.appTitle}>Stool Tracker</h1>
          
          {authState.type === 'authenticated' && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className={styles.userMenuTrigger}>
                  <User size={16} />
                  {authState.user.displayName}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut size={16} style={{ marginRight: 8 }} />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
          
          {authState.type === 'loading' && (
            <div className={styles.userMenuSkeleton}>
              <div className={styles.skeleton}></div>
            </div>
          )}
        </div>
      </header>
      
      <main className={styles.mainContent}>
        {children}
      </main>
    </div>
  );
};