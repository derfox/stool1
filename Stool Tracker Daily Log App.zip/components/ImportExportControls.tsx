import React, { useState, useCallback } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { FileSpreadsheet, FileJson, Upload, CheckCircle, XCircle } from 'lucide-react';

import { Button } from './Button';
import { FileDropzone } from './FileDropzone';
import { Spinner } from './Spinner';
import { getExportData } from '../endpoints/data/export_GET.schema';
import { postImportData, type OutputType as ImportResult } from '../endpoints/data/import_POST.schema';

import styles from './ImportExportControls.module.css';

export const ImportExportControls = ({ className }: { className?: string }) => {
  const queryClient = useQueryClient();
  const [isExportingCsv, setIsExportingCsv] = useState(false);
  const [isExportingJson, setIsExportingJson] = useState(false);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [importError, setImportError] = useState<string | null>(null);

  const handleExport = useCallback(async (format: 'csv' | 'json') => {
    const setLoading = format === 'csv' ? setIsExportingCsv : setIsExportingJson;
    setLoading(true);
    try {
      const blob = await getExportData({ format });
      
      // Try multiple download approaches for iframe compatibility
      const filename = `stool-entries.${format}`;
      
      // Method 1: Try the traditional approach first
      if (window.URL && window.URL.createObjectURL) {
        try {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.style.display = 'none';
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
          a.remove();
        } catch (urlError) {
          console.warn('createObjectURL method failed, trying alternative:', urlError);
          throw new Error('Download method not supported in this environment');
        }
      } else {
        // Method 2: Direct blob download for environments without createObjectURL
        const reader = new FileReader();
        reader.onload = function() {
          const dataUrl = reader.result as string;
          const a = document.createElement('a');
          a.style.display = 'none';
          a.href = dataUrl;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          a.remove();
        };
        reader.readAsDataURL(blob);
      }
      
      toast.success(`Successfully exported data as ${format.toUpperCase()}.`);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'An unknown error occurred during export.';
      console.error(`Export failed for format ${format}:`, error);
      toast.error(message);
    } finally {
      setLoading(false);
    }
  }, []);

  const importMutation = useMutation({
    mutationFn: (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      return postImportData(formData);
    },
    onSuccess: (data) => {
      setImportResult(data);
      setImportError(null);
      toast.success(data.message);
      // Invalidate all queries to refresh data across the app
      queryClient.invalidateQueries();
    },
    onError: (error) => {
      const message = error instanceof Error ? error.message : 'An unknown error occurred during import.';
      setImportError(message);
      setImportResult(null);
      console.error('Import failed:', error);
      toast.error(message);
    },
  });

  const handleFileSelect = useCallback((files: File[]) => {
    if (files.length > 0) {
      setImportResult(null);
      setImportError(null);
      importMutation.mutate(files[0]);
    }
  }, [importMutation]);

  const isExporting = isExportingCsv || isExportingJson;

  return (
    <div className={`${styles.container} ${className ?? ''}`}>
      <section className={styles.section}>
        <h2 className={styles.header}>Export Data</h2>
        <p className={styles.description}>Download all your stool entry data in either CSV or JSON format.</p>
        <div className={styles.buttonGroup}>
          <Button
            onClick={() => handleExport('csv')}
            disabled={isExporting}
            variant="secondary"
          >
            {isExportingCsv ? <Spinner size="sm" /> : <FileSpreadsheet size={16} />}
            Export as CSV
          </Button>
          <Button
            onClick={() => handleExport('json')}
            disabled={isExporting}
            variant="secondary"
          >
            {isExportingJson ? <Spinner size="sm" /> : <FileJson size={16} />}
            Export as JSON
          </Button>
        </div>
      </section>

      <div className={styles.divider} />

      <section className={styles.section}>
        <h2 className={styles.header}>Import Data</h2>
        <p className={styles.description}>Upload a previously exported CSV or JSON file to restore your data. Duplicates based on entry date will be skipped.</p>
        
        {importMutation.isPending ? (
          <div className={styles.loadingOverlay}>
            <Spinner size="lg" />
            <p>Importing data, please wait...</p>
          </div>
        ) : (
          <FileDropzone
            onFilesSelected={handleFileSelect}
            accept=".csv,application/json"
            maxFiles={1}
            disabled={importMutation.isPending}
            icon={<Upload size={40} />}
            title="Click or drag file to this area to upload"
            subtitle="Supports .csv and .json files"
          />
        )}

        {importResult && (
          <div className={`${styles.resultMessage} ${styles.success}`}>
            <CheckCircle size={20} />
            <div>
              <p className={styles.resultTitle}>Import Successful</p>
              <p>{importResult.message}</p>
            </div>
          </div>
        )}
        {importError && (
          <div className={`${styles.resultMessage} ${styles.error}`}>
            <XCircle size={20} />
            <div>
              <p className={styles.resultTitle}>Import Failed</p>
              <p>{importError}</p>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};