import React, { useState, useEffect } from 'react';
import {
  Wifi,
  WifiOff,
  Cloud,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useOnlineStatus } from '../helpers/useOnlineStatus';
import { useOfflineSync } from '../helpers/useOfflineSync';
import { Button } from './Button';
import { Badge } from './Badge';
import styles from './OfflineIndicator.module.css';

export const OfflineIndicator = ({ className }: { className?: string }) => {
  const isOnline = useOnlineStatus();
  const { sync, syncStatus, lastSync, pendingOperations } = useOfflineSync();
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    if (syncStatus === 'success') {
      setShowSuccess(true);
      const timer = setTimeout(() => setShowSuccess(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [syncStatus]);

  const isVisible =
    !isOnline ||
    pendingOperations > 0 ||
    syncStatus === 'syncing' ||
    syncStatus === 'error' ||
    showSuccess;

  if (!isVisible) {
    return null;
  }

  const getStatusContent = () => {
    if (!isOnline) {
      return {
        icon: <WifiOff size={18} className={styles.icon} />,
        text: 'Offline',
        badgeVariant: 'outline' as const,
        action: (
          <Button
            size="sm"
            variant="ghost"
            onClick={sync}
            disabled={true}
            title="Sync is disabled while offline"
          >
            Sync
          </Button>
        ),
      };
    }

    switch (syncStatus) {
      case 'syncing':
        return {
        icon: <Cloud size={18} className={`${styles.icon} ${styles.syncingIcon}`} />,
          text: 'Syncing...',
          badgeVariant: 'default' as const,
        };
      case 'error':
        return {
          icon: <AlertCircle size={18} className={`${styles.icon} ${styles.errorIcon}`} />,
          text: 'Sync Error',
          badgeVariant: 'destructive' as const,
          action: (
            <Button size="sm" variant="ghost" onClick={sync}>
              <RefreshCw size={14} />
              Retry
            </Button>
          ),
        };
      case 'success':
        if (showSuccess) {
          return {
            icon: <CheckCircle2 size={18} className={`${styles.icon} ${styles.successIcon}`} />,
            text: 'Synced',
            subtext: lastSync ? `Last sync ${formatDistanceToNow(lastSync, { addSuffix: true })}` : '',
          };
        }
        return null; // Handled by isVisible
      case 'idle':
      default:
        if (pendingOperations > 0) {
          return {
            icon: <Wifi size={18} className={styles.icon} />,
            text: 'Online',
            badgeVariant: 'secondary' as const,
            action: (
              <Button size="sm" variant="ghost" onClick={sync}>
                Sync Now
              </Button>
            ),
          };
        }
        return null; // Handled by isVisible
    }
  };

  const content = getStatusContent();

  if (!content) {
    return null;
  }

  const { icon, text, subtext, badgeVariant, action } = content;

  return (
    <div className={`${styles.container} ${className || ''}`}>
      <div className={styles.statusSection}>
        {icon}
        <div className={styles.textContainer}>
          <span className={styles.statusText}>{text}</span>
          {subtext && <span className={styles.subtext}>{subtext}</span>}
        </div>
      </div>
      <div className={styles.actionsSection}>
        {pendingOperations > 0 && badgeVariant && (
          <Badge variant={badgeVariant} className={styles.badge}>
            {pendingOperations} pending
          </Badge>
        )}
        {action}
      </div>
    </div>
  );
};