import React from 'react';
import { BRISTOL_SCALE_INFO, getBristolScaleColorVar, type BristolScale } from '../helpers/bristolScale';
import styles from './BristolScaleSelector.module.css';

interface BristolScaleSelectorProps {
  value: number;
  onChange: (value: number) => void;
  className?: string;
}

export const BristolScaleSelector = ({ value, onChange, className }: BristolScaleSelectorProps) => {
  return (
    <div className={`${styles.grid} ${className || ''}`}>
      {BRISTOL_SCALE_INFO.map((item) => (
        <button
          key={item.scale}
          type="button"
          className={`${styles.card} ${value === item.scale ? styles.selected : ''}`}
          onClick={() => onChange(item.scale)}
          style={{ '--bristol-color': `var(${getBristolScaleColorVar(item.scale as BristolScale)})` } as React.CSSProperties}
        >
          <div className={styles.scaleNumber}>{item.scale}</div>
          <div className={styles.description}>{item.description}</div>
        </button>
      ))}
    </div>
  );
};