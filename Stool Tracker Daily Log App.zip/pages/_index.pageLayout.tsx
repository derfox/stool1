import { UserRoute } from '../components/ProtectedRoute';
import { SharedLayout } from '../components/SharedLayout';

export default [UserRoute, SharedLayout];